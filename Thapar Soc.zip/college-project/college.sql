-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2018 at 10:04 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


-- Table structure for table `cont`
--

CREATE TABLE `cont` (
  `id` int(255) NOT NULL,
  `name` varchar(500) NOT NULL,
  `roll_no` varchar(500) NOT NULL,
  `phn` varchar(500) NOT NULL,
  `branch` varchar(1000) NOT NULL,
  `course` varchar(500) NOT NULL,
  `year` varchar(500) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `society_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cont`
--

INSERT INTO `cont` (`id`, `name`, `roll_no`, `phn`, `branch`, `course`, `year`, `email`, `society_id`) VALUES
(8, 'adsf', '323', '31231', '', 'CSE', '1st', 'q@gmail.com', 25),
(9, 'afsda', '123123', '1234567890', '', 'CSE', '2nd', '', 25),
(10, 'gurnir', '121', '9855587030', '', 'CSE', '3rd', '', 25),
(11, 'tst', '2131', '1234567890', 'BRANCH', 'COURSE', '1st', '', 25),
(12, 'Shlok Chanduka', '101408121', '8725259878', 'MEE', 'B.E', '4th', '', 47);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(100) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `society` varchar(100) DEFAULT NULL,
  `datee` varchar(1000) DEFAULT NULL,
  `society_name` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `image`, `name`, `description`, `society`, `datee`, `society_name`) VALUES
(1, '', 'new', 'newasfdafd', 'sfdgs', '11/11/2018', 0),
(2, 'upload/_1526286590.', 'sdfasd', NULL, NULL, NULL, 0),
(3, 'uploads/_1526286907.', 'sadfa', NULL, NULL, NULL, 0),
(4, 'uploads/_1526287001.', 'zfa', NULL, NULL, NULL, 0),
(5, 'uploads/_1526287059.', 'sds', NULL, NULL, NULL, 0),
(6, 'uploads/_1526287121.', 'sdfa', NULL, NULL, NULL, 0),
(7, 'upload/_1526289788.', '', NULL, NULL, NULL, 0),
(8, 'upload/_1526289827.', '', NULL, NULL, NULL, 0),
(9, 'upload/_1526290020.', '', NULL, NULL, NULL, 0),
(10, 'upload/_1526290145.', '', NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_answers`
--

CREATE TABLE `forum_answers` (
  `id` int(11) NOT NULL,
  `answer` text NOT NULL,
  `forum_question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `forum_questions`
--

CREATE TABLE `forum_questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `society_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `description` longtext NOT NULL,
  `society` varchar(255) DEFAULT NULL,
  `datee` varchar(255) NOT NULL,
  `notes` varchar(1000) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image`, `name`, `description`, `society`, `datee`, `notes`, `user_id`) VALUES
(17, 'frosh1.jpg', 'Frosh Week 2018', 'Frosh Week helps student to get comfortable with college environment and also it helps you to find your interest so that you can choose your society accordingly.', 'Frosh Society', '08/08/2018', '', 13003),
(18, 'exo.jpg', 'Exordium', 'It is a event for freshers where they get to know about the alumnis and also it is a cultural night.', 'Student Alumni Interaction Cell', '08/09/2018', '', 13003),
(19, 'spicmacay.jpg', 'Qawali Night', 'Its a night where sufi performers performs and they creates a sufi environment.', 'Spicmacay Thapar Chapter', '27/09/2018', '', 13003),
(20, 'tmc.jpg', 'Cineyouth Film Festival', 'CineYouth is one of very few college level film festivals in the India devoted to highlighting and showcasing films made by young filmmakers. With an emphasis on education as well as screenings of officially selected films, CineYouth will provide participants with a ', 'Thapar Movie Club', '03/03/2019', '', 13003);

-- --------------------------------------------------------

--
-- Table structure for table `society`
--

CREATE TABLE `society` (
  `id` int(100) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `society_name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `event` varchar(500) NOT NULL,
  `head` varchar(500) NOT NULL,
  `user_id` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `society`
--

INSERT INTO `society` (`id`, `image`, `society_name`, `description`, `event`, `head`, `user_id`) VALUES
(41, 'frosh.jpg', 'Frosh Society', 'FROSH comprises of various events for the fresher class of Thapar Institute of Engineering and Technology to ease them into their new surroundings.', 'Frosh Week 2018', 'Dr. M.D Singh', 13055),
(42, '27540104_1178722025592995_3168658544532122066_n.jpg', 'Spicmacay Thapar Chapter', 'Society For Promotion Of Indian Classical Music and Culture Amongst Youth. A national movement started 4 decades back to preserve the rich Indian culture.', 'Qawali Night', 'Dr. Rajesh Khanna', 13052),
(43, '19146022_341085359641177_8220168823205183864_n.jpg', 'Thapar Food Festival', 'Thapar Food Festival is the first fest to be organized by an Indian University, an extravaganza which celebrates food. We strive to bring together the best food providers from all over world under one roof for food lovers to indulge in their specialties!', 'TFF FEST 2018', 'Mr. Subhash chandra bose', 13053),
(44, '16299344_806358076169916_3320442044883788572_n.jpg', 'Creative Computing Society', 'The Creative Computing Society (CCS) is one of the top functioning technical societies at TIET, dedicated to Computer Science and Technology.', 'Code Runners', 'Dr. Inderveer Chana', 13054),
(45, '27545198_2086800374669196_7356117070354266159_n.jpg', 'Thapar Adventure Club', 'Adventure Club @ Thapar university...Our main motive is to induce the spirit of adventure n passion in the students of our university and carry out as many adventure sports related activity in a minimal budget as possible.', 'Rishikesh Trip', 'Dr. Gagandeep kaur', 13051),
(46, '13932709_1138140402896287_4112652493829256392_n.jpg', 'Thapar Movie Club', 'Thapar movie club or TMC consists of a bunch of movie enthusiasts whose sole aim is appreciation and promotion of good cinema. We provide the wannabe actors, directors, script writers the platform they deserve. Special workshops are conducted to bring forward and enhance such talents. Weâ€™re not just people working in different sections but a team working together to bring out the the best. We try to make eminent movies involving all those people and together work out everything right and that ', 'Society Orientation', 'Dr. Manmohan Chhibber', 13046),
(47, 'saic1.jpg', 'Student Alumni Interaction Cell', 'Student Alumni Interaction Cell (SAIC) is an institute body run by the students of TIET, under the guidance of Thapar University Alumni Association (TUAA) & Dean of Student Affairs (DoSA), devoted towards the enhancement of relations between the students and alumni community.', 'Exordium', 'Mr. Rajeev Sharda', 13047),
(49, 'litsoc.jpg', 'Literaray Society', 'Literary Society is a blend of writers, quizzers, actors, poets, speakers and artists who excel in the arena of literature, frame the ladder of intellectualism step by step and guide everyone to zenith.', 'Eclectiza', 'Dr. Apurva Bakshi', 13058),
(50, 'nox.jpg', 'NOX Dance Society', 'NOX-The Dance Society of Thapar University,Patiala.', 'NOX Night', 'Dr. Swati Sondhi', 13059);

-- --------------------------------------------------------

--
-- Table structure for table `society_members`
--

CREATE TABLE `society_members` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `society_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `society_members`
--

INSERT INTO `society_members` (`id`, `user_id`, `society_id`) VALUES
(1, 13030, 25),
(2, 13038, 29),
(5, 13041, 29),
(6, 13042, 29),
(7, 13044, 29),
(8, 13057, 47);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `course` varchar(60) DEFAULT NULL,
  `semester` varchar(40) DEFAULT NULL,
  `role` varchar(20) NOT NULL,
  `token` varchar(30) DEFAULT NULL,
  `contact` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `course`, `semester`, `role`, `token`, `contact`) VALUES
(13002, 'bansal@gmail.com', '123', 'neha', 'CSE', '2nd', 'student', NULL, ''),
(13003, 'admin@thapar.edu', '123', 'Rahul', '', '', 'admin', NULL, ''),
(13007, 'manrpeet@gmail.com', '123', '+919855587030', 'CSE', '1st', 'student', NULL, ''),
(13008, 'happy@gmail.com', '123', '232123', 'CSE', '1st', 'student', NULL, ''),
(13009, 'jha@gmail.com', '123', '897979', 'CSE', '1st', 'student', NULL, ''),
(13010, 'fjak@GMAIL.COM', '123', 'KLAJDFLK', 'CSE', '1st', 'student', NULL, ''),
(13011, 'adminJH@gmail.com', '123', '2321', 'CSE', '1st', 'student', NULL, ''),
(13012, 'youthunited@gmail.com', '123', 'Youth United', NULL, NULL, 'teacher', NULL, ''),
(13023, 'mem@gmail.com', '123', 'rap', NULL, NULL, 'member', NULL, '9899'),
(13024, 'w@gmail.com', '123', 'member1', NULL, NULL, 'member', NULL, '9090'),
(13025, 'jasss@gmail.com', '123', 'tssss', NULL, NULL, 'member', NULL, '1213'),
(13028, 'e@g.com', '123', 'kkk', NULL, NULL, 'member', NULL, '121'),
(13029, 'j@c.om', '123', 'kjfalk', NULL, NULL, 'member', NULL, '121'),
(13030, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13031, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13032, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13033, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13034, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13035, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13036, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13037, 'dd@gmail.com', '123', 'adfa', NULL, NULL, 'member', NULL, '1132'),
(13038, 'mem@f.com', '123', 'happy', NULL, NULL, 'member', NULL, '12311'),
(13041, 'chc@gmail.con', '123', 'checking', NULL, NULL, 'member', NULL, '1231'),
(13042, 'gur@gmail.com', '123', 'gur', NULL, NULL, 'member', NULL, '124'),
(13044, 'rahul@gmail.com', '123', 'rahul', NULL, NULL, 'member', NULL, '1234'),
(13046, 'tmc@thapar.edu', '123', 'Dr. Manmohan Chhibber', NULL, NULL, 'teacher', NULL, '+91-9463600569'),
(13047, 'saic@thapar.edu', 'saic', 'Mr. Rajeev Sharda', NULL, NULL, 'teacher', NULL, '98745632101'),
(13051, 'tac@thapar.edu', 'tac', 'Dr. Gagandeep kaur', NULL, NULL, 'teacher', NULL, '8146722433'),
(13052, 'spicmacay@thapar.edu', 'spicmacay', 'Dr. Rajesh Khanna', NULL, NULL, 'teacher', NULL, '9872883263'),
(13053, 'tff@thapar.edu', 'tff', 'Mr. Subhash chandra bose', NULL, NULL, 'teacher', NULL, '7837726619'),
(13054, 'ccs@thapar.edu', 'ccs', 'Dr. Inderveer Chana', NULL, NULL, 'teacher', NULL, '9417244465'),
(13055, 'frosh@thapar.edu', 'frosh', 'Dr. M.D Singh', NULL, NULL, 'teacher', NULL, '9815605616'),
(13057, 'mohitkant@gmail.com', '123', 'Mohit Kant', NULL, NULL, 'member', NULL, '101406190'),
(13058, 'litsoc@thapar.edu', 'litsoc', 'Dr. Apurva Bakshi', NULL, NULL, 'teacher', NULL, '9876541563'),
(13059, 'nox@thapar.edu', 'nox', 'Dr. Swati Sondhi', NULL, NULL, 'teacher', NULL, '7539513698');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cont`
--
ALTER TABLE `cont`
  ADD PRIMARY KEY (`id`),
  ADD KEY `society_id` (`society_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum_answers`
--
ALTER TABLE `forum_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `forum_question_id` (`forum_question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `forum_questions`
--
ALTER TABLE `forum_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `society_id` (`society_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `society`
--
ALTER TABLE `society`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `society_members`
--
ALTER TABLE `society_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `society_id` (`society_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cont`
--
ALTER TABLE `cont`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `forum_answers`
--
ALTER TABLE `forum_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `forum_questions`
--
ALTER TABLE `forum_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `society`
--
ALTER TABLE `society`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `society_members`
--
ALTER TABLE `society_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13060;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `forum_answers`
--
ALTER TABLE `forum_answers`
  ADD CONSTRAINT `forum_answers_ibfk_1` FOREIGN KEY (`forum_question_id`) REFERENCES `forum_questions` (`id`),
  ADD CONSTRAINT `forum_answers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `forum_questions`
--
ALTER TABLE `forum_questions`
  ADD CONSTRAINT `forum_questions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `forum_questions_ibfk_2` FOREIGN KEY (`society_id`) REFERENCES `society` (`id`);

--
-- Constraints for table `society`
--
ALTER TABLE `society`
  ADD CONSTRAINT `society_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
--
-- Database: `forum`
--
CREATE DATABASE IF NOT EXISTS `forum` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `forum`;

-- --------------------------------------------------------

--
-- Table structure for table `forum_topic`
--

CREATE TABLE `forum_topic` (
  `forum_topic_id` int(11) NOT NULL,
  `forum_topic_name` text NOT NULL,
  `forum_topic_created_by` varchar(255) NOT NULL,
  `forum_topic_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `forum_topic_body` text NOT NULL,
  `forum_topic_views` int(11) DEFAULT NULL,
  `forum_topic_replies` int(11) DEFAULT NULL,
  `forum_topic_semester` varchar(255) DEFAULT NULL,
  `forum_topic_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_topic`
--

INSERT INTO `forum_topic` (`forum_topic_id`, `forum_topic_name`, `forum_topic_created_by`, `forum_topic_time`, `forum_topic_body`, `forum_topic_views`, `forum_topic_replies`, `forum_topic_semester`, `forum_topic_image`) VALUES
(12, 'How to enroll for frosh society?', '101403145', '2018-06-02 22:55:16', 'dccc', NULL, NULL, NULL, ''),
(13, 'qq', '123456', '2018-06-03 12:33:59', 'qqqqq', NULL, NULL, NULL, ''),
(14, 'How to develop coding skills?', '101403145', '2018-06-03 17:23:47', 'I would love to be a part of a society which helps to develop coding skills.', NULL, NULL, NULL, ''),
(15, 'How to get admission in Thapar?', 'mishraboy', '2018-06-03 19:06:12', 'I got 57 marks in jee-mains, can i get CS in Thapar?', NULL, NULL, NULL, 'logo-449466955.png');

-- --------------------------------------------------------

--
-- Table structure for table `forum_topic_reply`
--

CREATE TABLE `forum_topic_reply` (
  `forum_topic_reply_id` int(11) NOT NULL,
  `forum_topic_reply_topic_id` int(11) NOT NULL,
  `forum_topic_reply_created_by` varchar(255) NOT NULL,
  `forum_topic_reply_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `forum_topic_reply_body` text NOT NULL,
  `forum_topic_reply_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_topic_reply`
--

INSERT INTO `forum_topic_reply` (`forum_topic_reply_id`, `forum_topic_reply_topic_id`, `forum_topic_reply_created_by`, `forum_topic_reply_time`, `forum_topic_reply_body`, `forum_topic_reply_image`) VALUES
(1, 1, 'nirmalya', '2015-02-19 08:52:25', 'Piyush!', ''),
(2, 1, 'dibyo', '2015-02-19 09:08:38', 'hi!', ''),
(3, 2, 'rajarshi', '2015-04-14 17:58:57', 'Hello!', ''),
(4, 5, 'rajarshi', '2015-04-15 05:50:19', 'This is a test comment.', '6req95cnq8-1207729972.jpg'),
(5, 1, 'rajarshi', '2015-04-15 05:57:54', 'Test.', '1lde62496n-559284060.jpg'),
(6, 5, 'rajarshi', '2015-04-15 06:12:22', 'Okay!', 'default-background.jpg'),
(7, 5, 'rajarshi', '2015-04-15 06:14:36', 'hi!', 'default-background.jpg'),
(8, 5, 'rajarshi', '2015-04-15 06:15:06', 'ok!', 'NULL'),
(9, 5, 'rajarshi', '2015-04-15 06:15:48', 'this!', ''),
(10, 1, 'jadgeep', '2018-05-13 11:37:00', 'helo', ''),
(11, 7, 'jadgeep', '2018-05-13 11:44:37', 'hello', ''),
(12, 1, '101403145', '2018-06-02 15:48:34', 'yooooo', 'invitation-1070200399.docx'),
(13, 3, '101403145', '2018-06-02 16:17:39', '', ''),
(14, 3, '101403145', '2018-06-02 16:18:08', 'hjjhvhj', 'barmer-history-481740791.jpg'),
(15, 12, '101403145', '2018-06-02 22:55:27', 'ccc', ''),
(16, 12, 'suresh', '2018-06-03 07:33:51', 'its easy', ''),
(17, 12, '123456', '2018-06-03 12:34:47', 'i m interested in that society', ''),
(18, 14, '101403145', '2018-06-03 17:24:40', 'Contact them', '27798216_1019980951474293_1706113721901001931_o-1216078138.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `notice_topic`
--

CREATE TABLE `notice_topic` (
  `notice_topic_id` int(11) NOT NULL,
  `notice_topic_name` text NOT NULL,
  `notice_topic_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notice_topic_body` text NOT NULL,
  `notice_topic_created_by` varchar(255) NOT NULL,
  `notice_topic_semester` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_topic`
--

INSERT INTO `notice_topic` (`notice_topic_id`, `notice_topic_name`, `notice_topic_time`, `notice_topic_body`, `notice_topic_created_by`, `notice_topic_semester`) VALUES
(3, 'Piyush', '2015-02-19 09:04:15', 'Piyush kanti', 'nirmalya', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` text NOT NULL,
  `user_lastname` text NOT NULL,
  `user_avatar` varchar(255) NOT NULL,
  `user_shortbio` text,
  `user_username` varchar(255) NOT NULL,
  `user_longbio` text,
  `user_website` varchar(255) DEFAULT NULL,
  `user_dob` date DEFAULT NULL,
  `user_profession` text,
  `user_gender` varchar(255) DEFAULT NULL,
  `user_address` text,
  `user_backgroundpicture` varchar(255) NOT NULL,
  `user_joindate` date NOT NULL,
  `user_country` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_email`, `user_password`, `user_firstname`, `user_lastname`, `user_avatar`, `user_shortbio`, `user_username`, `user_longbio`, `user_website`, `user_dob`, `user_profession`, `user_gender`, `user_address`, `user_backgroundpicture`, `user_joindate`, `user_country`) VALUES
(18, 'nirmalya.email@gmail.com', 'nirmalya', 'Nirmalya', 'Ghosh', 'default.jpg', '', 'nirmalya', NULL, NULL, '2015-02-19', NULL, NULL, NULL, 'default.jpg', '2015-02-19', NULL),
(19, 'dibyo@maj.com', 'dibyo', 'Dibyojoti', 'Majumdar', 'default.jpg', '', 'dibyo', NULL, NULL, '2015-02-11', NULL, NULL, NULL, 'default.jpg', '2015-02-19', NULL),
(21, 'rajarshi@tarafdar.com', 'rajarshi', 'Rajarshi', 'Tarafdar', '481ewwfvjs-850738315.jpg', '', 'rajarshi', NULL, NULL, '2015-04-02', NULL, NULL, NULL, 'default.jpg', '2015-04-14', NULL),
(22, 'jagdeep@gmail.com', '123', 'jagdeep', 'singh', 'default.jpg', '', 'jadgeep', NULL, NULL, '2018-05-12', NULL, NULL, NULL, 'default.jpg', '2018-05-13', NULL),
(23, 'ts@gmail.com', '12345', 'test', 'singh', 'ipad-pro-5284847253.png', 'helo', '1234', NULL, NULL, '2018-05-05', NULL, NULL, NULL, 'default.jpg', '2018-05-13', NULL),
(24, 'again@gmail.com', '123345', 'aga', 'sug', 'default.jpg', NULL, '12344', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-05-13', NULL),
(25, 'de@gmail.com', '123456', 'dep', 'sigh', 'default.jpg', NULL, '300', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-05-13', NULL),
(26, 'e@gmail.com', '1234567', 'tes', 'asda', 'default.jpg', NULL, '12341', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-05-13', NULL),
(27, 'rahulkaga@gmail.com', '123', 'rahul', 'kaga', 'default.jpg', NULL, '101403145', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-06-01', NULL),
(28, 'sureshkakar@gmail.com', '123', 'suresh', 'kakkar', 'default.jpg', NULL, 'suresh', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-06-03', NULL),
(29, 'q@gmail.com', '123', 'q', 'q', 'default.jpg', NULL, '123456', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-06-03', NULL),
(30, 'victoriousrachit@gmail.com', '123', 'Rachit', 'Mishra', 'default.jpg', NULL, 'mishraboy', NULL, NULL, NULL, NULL, NULL, NULL, 'default.jpg', '2018-06-04', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `forum_topic`
--
ALTER TABLE `forum_topic`
  ADD PRIMARY KEY (`forum_topic_id`);

--
-- Indexes for table `forum_topic_reply`
--
ALTER TABLE `forum_topic_reply`
  ADD PRIMARY KEY (`forum_topic_reply_id`);

--
-- Indexes for table `notice_topic`
--
ALTER TABLE `notice_topic`
  ADD PRIMARY KEY (`notice_topic_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD UNIQUE KEY `user_username` (`user_username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `forum_topic`
--
ALTER TABLE `forum_topic`
  MODIFY `forum_topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `forum_topic_reply`
--
ALTER TABLE `forum_topic_reply`
  MODIFY `forum_topic_reply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `notice_topic`
--
ALTER TABLE `notice_topic`
  MODIFY `notice_topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"college\",\"table\":\"users\"},{\"db\":\"college\",\"table\":\"society_members\"},{\"db\":\"college\",\"table\":\"society\"},{\"db\":\"college\",\"table\":\"cont\"},{\"db\":\"forum\",\"table\":\"user\"},{\"db\":\"forum\",\"table\":\"notice_topic\"},{\"db\":\"forum\",\"table\":\"forum_topic\"},{\"db\":\"forum\",\"table\":\"forum_topic_reply\"},{\"db\":\"bookfoxi_tx\",\"table\":\"societies\"},{\"db\":\"college\",\"table\":\"assignments\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float UNSIGNED NOT NULL DEFAULT '0',
  `y` float UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2018-03-25 15:53:39', '{\"collation_connection\":\"utf8mb4_unicode_ci\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
