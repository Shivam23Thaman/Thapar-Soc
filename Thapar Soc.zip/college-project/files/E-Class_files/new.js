 $('.present').on('click', function(e) {
 	
 	var tid = $('.teacher_id').val();
 	var sid = $(this).attr('id');
 	var course = $('.course').val();
 	var semester = $('#semester').val();

 	var present = $(this).attr("data-id");      
   var btn = $(this);

   $.ajax({
     url: "mark_attendance.php",
     type: "post",
     data:  { tid, sid, course, semester, present},
     success: function (response) {
           // you will get response from your php page (what you echo or print)  
           console.log(response);               
           if(response == 'present'){
           	btn.removeClass('btn-warning');
           	btn.addClass('btn-success');
           } else if(response == 'marked'){
             alert('Attendance Marked');
           } else if(response == 'pAftera'){
            $('.absent-'+ sid).removeClass('btn-danger');
            $('.absent-'+ sid).addClass('btn-default');
            btn.removeClass('btn-warning');
            btn.addClass('btn-success');
          }
        }
      });

 });

 $('.absent').on('click', function(e) {

  var tid = $('.teacher_id').val();
  var sid = $(this).attr('id');
  var course = $('.course').val();
  var semester = $('.semester').val();
  var absent = $(this).attr("data-id");      
  var btn = $(this);

/*var pBtn = $('.present').attr('data-btn-id');
 var res = pBtn.split("-");*/

  $.ajax({
    url: "mark_attendance.php",
    type: "post",
    data:  { tid, sid, course, semester, absent} ,
    success: function (response) {
           // you will get response from your php page (what you echo or print)  
           console.log(response);               
           if(response == 'absent'){
            btn.removeClass('btn-default');
            btn.addClass('btn-danger');
          } else if(response == 'aAfterp'){
            btn.removeClass('btn-default');
            btn.addClass('btn-danger');
            $('.present-'+ sid).removeClass('btn-success');
            $('.present-'+ sid).addClass('btn-warning');
          }
        }
      });

});

 $('#changeSem').on('show.bs.modal', function(e) {
    //get data-id attribute of the clicked element
   var studentId = $(e.relatedTarget).data('id');
   var semester = $(e.relatedTarget).data('semester');
    
    $('.student_id').val(studentId);
    $('.semester').val(semester);
});


/*$( "#email" ).keypress(function() {
   document.getElementById("parent_id").disabled = true;
});
$( "#parent_id" ).keypress(function() {
   document.getElementById("email").disabled = true;
});*/


/*$( "#email" ).keypress(function() {
   $("#parent_id").val('');
});
$( "#parent_id" ).keypress(function() {
   $("#email").val('');
});*/