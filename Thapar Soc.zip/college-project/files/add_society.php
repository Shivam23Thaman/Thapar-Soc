m<!DOCTYPE html>
<html lang="en">
<?php @include 'config.php'; ?>
<head>
<?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
<div class="preloader">
<svg class="circular" viewBox="25 25 50 50">
<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
</div>
<div id="main-wrapper">
<?php @include 'header.php'; ?>
<?php @include 'sidebar.php'; ?>
<div class="page-wrapper">
<div class="container-fluid">
<div class="row page-titles">
<div class="col-md-6 col-8 align-self-center">
<h3 class="text-themecolor m-b-0 m-t-0">Add Society</h3>
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
<li class="breadcrumb-item active">Add Society</li>
</ol>
</div>
<div class="col-md-6 col-4 align-self-center">
</div>
</div>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-6">
<div class="card">
<div class="card-block">
<h4 class="card-title text-center">Add Society</h4>
<form class="form-horizontal form-material" action="main.php?act=society" method="POST"  enctype="multipart/form-data">                        <input type="hidden" name="size" value="1000000">
     <div class="form-group">
        <label class="col-md-12">Society Image</label>
        <div class="col-md-12">
             <input type="file" name="image">
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-12">Name</label>
        <div class="col-md-12">
            <input type="text" class="form-control form-control-line" name="society_name">
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-12">Description</label>
        <div class="col-md-12">
            <input type="text" class="form-control form-control-line" name="description" >
        </div>
    </div>
    <div class="form-group">
        <label class="col-md-12">Upcoming Event</label>
        <div class="col-md-12">
            <input type="text" class="form-control form-control-line" name="event">
        </div>
    </div>
   
    
    <div class="form-group">
                                        <label class="col-md-12">Select Head</label>
                                        <select name="head" class="custom-select">
                                        <?php
                                    //$id = $_SESSION['id'];
                                   $result = mysqli_query($conn,"SELECT * FROM `users`");
                                   while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    
                                        <option value="<?php echo $row['id'];?>,<?php echo $row['name'] ?>"><?php echo $row['name']; ?></option> 
                        
                                   
                                    <?php } ?>
                                    </select>
                                    </div>
    
    <div class="form-group">
        <div class="col-sm-12">
            <input type="submit"  class="btn btn-success"  name="upload">Add Society</button>
        </div>
    </div>
</form>
</div>
</div>
</div>
</div>
</div>
<footer class="footer text-center">
Thapar Soc
</footer>
</div>
</div>
<?php @include 'footer.php'; ?>
</body>
</html>