Member<!DOCTYPE html>
<html lang="en">
<?php @include 'config.php'; ?>
<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
            <?php @include 'header.php'; ?>
            <?php @include 'sidebar.php'; ?>
            <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row page-titles">
                        <div class="col-md-6 col-8 align-self-center">
                            <h3 class="text-themecolor m-b-0 m-t-0">Add Head</h3>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Add Head</li>
                            </ol>
                        </div>
                        <div class="col-md-6 col-4 align-self-center">
                        </div>
                    </div>
                    <div class="row">
                     <div class="col-xs-12 col-sm-12 col-md-6">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title text-center">Add Head</h4>
                                <form class="form-horizontal form-material" action="main.php?act=add_teacher" method="post">                      
                                    <div class="form-group">
                                        <label class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="email" class="form-control form-control-line" name="email" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Name</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="name" required="required">
                                        </div>
                                    </div>
                                     <div class="form-group">
                                        <label class="col-md-12">Contact Number</label>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-line" name="contact" required="required">
                                        </div>
                                    </div>
                                     <div class="form-group">
                                        <label class="col-md-12">Password</label>
                                        <div class="col-md-12">
                                            <input type="password" class="form-control form-control-line" name="password" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" type="submit">Add Member</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer text-center">
                Thapar Soc
            </footer>
        </div>
    </div>
 <?php @include 'footer.php'; ?>
</body>
</html>