<!DOCTYPE html>
<?php @include 'config.php'; ?>
<html lang="en">

<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
            <?php @include 'header.php'; ?>
            <?php @include 'sidebar.php'; ?>
            <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row page-titles">
                        <div class="col-md-6 col-8 align-self-center">
                            <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">Dashboard</li>
                            </ol>
                        </div>
                        <div class="col-md-6 col-4 align-self-center">
                        </div>
                    </div>
                    <?php
                    $id = $_SESSION['id'];
                        $query = mysqli_query($conn,"SELECT `role` FROM `users` WHERE `id` = '$id' ");
                        $row = mysqli_fetch_assoc($query);
                        if($row['role'] == 'teacher'){ ?>
                    <!-- Row -->
               <div class="row">
                    <!-- Column -->
                   
                    <!-- Column -->
                    <
                    <!-- Column -->
                </div>
                    <!-- Row -->
                    <?php  } else if($row['role'] == 'student'){ ?> 
                    <!-- HTML For Student goes here -->

                    <?php} else{ ?> 
                        <!-- HTML For Admin goes here -->

                    <?php } ?>
                </div>
                <footer class="footer text-center">
                   Thapar Soc
                </footer>
            </div>
        </div>
       <?php @include 'footer.php'; ?>
    </body>
    </html>