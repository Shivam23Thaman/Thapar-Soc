<?php

$act = $_GET['act'];

switch($act){

case 'signup':

$email = $_POST['email'];
$name = $_POST['name'];
$course = $_POST['course'];
$semester = $_POST['semester'];
$password = $_POST['password'];

$query = mysqli_query($conn,"SELECT `id` FROM `users` WHERE `email` = '$email'");
$id = mysqli_num_rows($query);
if($id){
$_SESSION['msg'] = 'Email Already Exists';
header('location:login.php');
}else{
$query = "INSERT INTO `users`(email,password,name,course,semester,role) VALUES('$email','$password','$name','$course','$semester','student')";
if(mysqli_query($conn,$query)){
	$uid = mysqli_insert_id($conn);
	$_SESSION['id'] = $uid;
	$_SESSION['msg'] = 'Signup Successful';
	$url = 'index.php';
}	
}
break;
?>