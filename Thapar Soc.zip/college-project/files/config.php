<?php
@include 'connection.php';
if(!isset($_SESSION['id'])){
	header('location:login.php');
}else{
	$id = $_SESSION['id'];

	$user = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$id' ");
	$rowu = mysqli_fetch_assoc($user);
}

@include 'functions.php';
?>