<!DOCTYPE html>
        <?php @include 'config.php'; ?>
        <html lang="en">

        <head>
        <?php @include 'meta.php'; ?>
        </head>

        <body class="fix-header fix-sidebar card-no-border">
        <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
        <?php @include 'header.php'; ?>
        <?php @include 'sidebar.php'; ?>
        <div class="page-wrapper">
        <div class="container-fluid">
        <div class="row page-titles">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="text-themecolor m-b-0 m-t-0">Society</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">Enroll</li>
                </ol>
            </div>
            <div class="col-md-6 col-4 align-self-center">
            </div>
        </div>
        <!-- Row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title">All Enroll</h4>
                        <div class="table-responsive m-t-40">
                            <table class="table stylish-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Roll no</th>
                                        <th>Phone</th>
                                        <th>Course</th>
                                        <th>year</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                   
                                    $id = $_SESSION['id'];
                                   
                                   //$result = mysqli_query($conn,"SELECT  *FROM society INNER JOIN  users ON society.user_id = users.id");
                                   //while($row = mysqli_fetch_assoc($result)){
                                    $result = mysqli_query($conn,"SELECT * FROM cont c INNER JOIN society s ON c.society_id = s.id WHERE s.user_id = $id");
                                   while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    <tr>
                                        
                                        <td>
                                            <h6><?php echo $row['name']; ?></h6></td>
                                        <td><?=$row['roll_no'];?></td>
                                        <td><?=$row['phn'];?></td>
                                        <td><?=$row['course'];?></td>
                                        <td><?=$row['year'];?></td>
                                      
                                        

                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
        </div>
        <footer class="footer text-center">
        Thapar Soc
        </footer>
        </div>
        </div>
        <?php @include 'footer.php'; ?>
        </body>
        </html>