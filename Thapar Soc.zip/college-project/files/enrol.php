<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <style>
     .carousel-inner img {
      width: 100%;
      height: 100%;
  }
    .card-title {
    margin-bottom: .75rem;
    background: #e9ecef;
    padding: 20px;
}
  </style>
  
    <title></title>
</head>
<body>
    <?php include 'nav.php';
    $id = $_GET['id'];
    //echo $id;
  ?>
<div class="col-xs-12 col-sm-12 col-md-12">

                    <div class="card">
                        <div class="card-block">
                            <h4 class="card-title text-center">Enroll</h4>
                            <form class="form-horizontal form-material" action="main.php?act=cont" method="post">                       
                                <div class="form-group">
                                    <label class="col-md-12">Name</label>
                                    <div class="col-md-12">
                                        <input type="text" class="form-control form-control-line" name="name" required="required">
                                    </div>
                                     <div class="form-group">
                                    <label class="col-md-12">Roll Number</label>
                                    <div class="col-md-12">
                                        <input type="text" class="form-control form-control-line" name="roll" required="required">
                                    </div>
                                </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12">Phone Number</label>
                                    <div class="col-md-12">
                                        <input type="text" class="form-control form-control-line" name="phn" required="required">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-md-12">Branch</label>
                                    <div class="col-md-12">
                                     <div class="col-md-12">
                                     <input type="text" name="branch" class="form-control form-control-line" >
                                </div>
                                    </div>
                                <div class="form-group">
                                    <label class="col-md-12">Course</label>
                                    <div class="col-md-12">
                                     <input type="text" name="course" class="form-control form-control-line" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12">Year</label>
                                <div class="col-md-12">
                                 <select class="form-control form-control-line" name="semester" required="required">
                                    <option value="">Select Year</option>
                                    <option>1st</option>
                                    <option>2nd</option>
                                    <option>3rd</option>
                                    <option>4th</option>
                                   
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="society" value="<?= $id ?>">
                                
                        </div>
                        
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button class="btn btn-success" type="submit">submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>