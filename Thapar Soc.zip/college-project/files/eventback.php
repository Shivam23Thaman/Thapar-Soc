<?php
  // Create database connection
  $conn = mysqli_connect("localhost", "root", "root", "college");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
<title>Image Upload</title>
<style type="text/css">
   #content{
    width: 50%;
    margin: 20px auto;
    border: 1px solid #cbcbcb;
   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   #img_div{
    width: 80%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid #cbcbcb;
   }
   #img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width: 300px;
    height: 140px;
   }
</style>
</head>
<body>
<div id="content">
  <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div id='img_div'>";
        echo "<img src='upload/".$row['image']."' >";
        echo "<p>".$row['image_text']."</p>";
      echo "</div>";
    }
  ?>
  <form method="POST" action="main.php?act=event" enctype="multipart/form-data">
    <input type="hidden" name="size" value="1000000">
    <div>
      <input type="file" name="image">
    </div>
    <input type="text" name="name">
    <input type="text" name="description">
    <select name="society" class="custom-select">
    <?php
                                    //$id = $_SESSION['id'];
                                   $result = mysqli_query($conn,"SELECT * FROM `society`");
                                   while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    
                                        <option value="<?php echo $row['society_name'];?>"><?php echo $row['society_name']; ?></option> 
                        
                                   
                                    <?php } ?>
    <input type="text" name="datee">
    <div>
      <button type="submit" name="upload">POST</button>
    </div>
  </form>
</div>
</body>
</html>