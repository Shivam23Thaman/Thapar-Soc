<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['msg'])){ ?>
<div class="alert alert-warning"><?php echo $_SESSION['msg']; ?></div>
<?php unset($_SESSION['msg']);} ?>

<?php
if(isset($_SESSION['id'])){
header('location:index.php');
}
?>
<html lang="en">
<head>
    <?php @include 'meta.php'; ?>
</head>
<body class="fix-header fix-sidebar card-no-border">
    <div class="main-wrapper"  style="background-color: #f2f7f8;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h3 style="padding-top: 50px;">Forget Password.</h3>
                </div>
            </div>
            <div class="row" style="padding-top: 90px; padding-bottom: 250px;">
                <div class="col-6 align-self-center">
                    <div class="card">
                        <div class="card-block">
                            <h4 class="card-title text-center">Enter Email</h4>
                             <?php
                                    $better_token = md5(uniqid(rand(), true));
                                    $unique_code = substr($better_token, 16);
                                    $uniqueid = $unique_code;
                            ?>
                            <form class="form-horizontal form-material" action="main.php?act=forget_password" method="post">
                                <input type="hidden" name="token" value="<?=$uniqueid;?>">
                                <div class="form-group">
                                    <label class="col-md-12">Email</label>
                                    <div class="col-md-12">
                                        <input type="email" class="form-control form-control-line" name="email" required="required">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <button class="btn btn-success" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>