<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['msg'])){ ?>
<div class="alert alert-warning"><?php echo $_SESSION['msg']; ?></div>
<?php unset($_SESSION['msg']);} ?>

<?php
if(isset($_SESSION['id'])){
header('location:index.php');
}
?>
<html lang="en">
<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="main-wrapper"  style="background-color: #f2f7f8;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h3 style="padding-top: 50px;">Forget Password.</h3>
                </div>
            </div>
            <div class="row" style="padding-top: 90px; padding-bottom: 250px;">
                <div class="col-6 align-self-center">
                    <div class="card">
                        <div class="card-block">
                            <h4 class="card-title text-center">Reset Password</h4>
                            <form class="form-horizontal form-material" action="main.php?act=reset_password" method="post">      
                        <input type="hidden" name="email" value="<?=$_GET['email'];?>">
                        <input type="hidden" name="token" value="<?=$_GET['token'];?>">        
                                <div class="form-group">
                                    <label class="col-md-12">Password</label>
                                    <div class="col-md-12">
                                        <input type="password" class="form-control form-control-line" name="password" required="required">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12">Confirm Password</label>
                                    <div class="col-md-12">
                                        <input type="password" class="form-control form-control-line" name="cpassword" required="required">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <button class="btn btn-success" type="submit">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>