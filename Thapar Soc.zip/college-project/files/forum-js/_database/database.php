<?php
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $database = "forum";
    $prefix = "root";
    $database=mysqli_connect($hostname,$user,$password,$database);
?>
