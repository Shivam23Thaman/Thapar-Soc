    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap/bootstrap.css" rel="stylesheet">
      
    <!-- Jasny Bootstrap CSS -->
    <link href="assets/css/jasny-bootstrap/jasny-bootstrap.css" rel="stylesheet">

    <!-- Bootstrap Form Helpers CSS -->
    <link href="assets/css/bootstrap-form-helpers/bootstrap-formhelpers.css" rel="stylesheet">  

    <!-- Animate CSS -->
    <link href="assets/css/animate/animate.css" rel="stylesheet">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome/font-awesome.css">

    <!-- PACE CSS -->
    <link rel="stylesheet" href="assets/css/pace/pace.css">

    <!-- Custom styles for this template -->
    <link href="assets/css/base/main.css" rel="stylesheet">