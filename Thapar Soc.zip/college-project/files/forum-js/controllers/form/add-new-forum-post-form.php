<form action="components/add-new-forum-post.php" method="post" enctype="multipart/form-data" id="UploadForm">
    <div class="form-group">
        <label for="forum-topic-name">Topic Name</label>
        <input type="text" class="form-control" id="forum-topic-name" name="forum_topic_name" placeholder="Enter Topic Name" required>
    </div>
    <div class="form-group">
        <label for="forum-topic-body">Topic Body</label>
        <textarea id="forum-topic-body" rows="9" class="form-control" placeholder="Body of the Topic" name="forum_topic_body" required></textarea>
    </div>
   
    <hr>
    <label for="forum-topic-attachment">Attachment</label>
    <input name="BackgroundImageFile" type="file" id="uploadBackgroundFile" class="btn btn-default" name="forum-topic-attachment"/>  
    <hr>
    <button type="submit" class="btn btn-primary" name="submit_button" id="submit_button">Submit</button>
</form>