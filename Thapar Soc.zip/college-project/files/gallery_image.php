<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

  <style>
      div.gallery {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 180px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: auto;
}

div.desc {
    padding: 15px;
    text-align: center;
}
  </style>
</head>
<body>
   <?php include 'nav.php';
  ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <CENTER><h1> Event Images </h1></CENTER>
            <br>

<?php
     $files = glob("gallery/*.*");
     for ($i=0; $i<count($files); $i++)
      {
        $image = $files[$i];
        $supported_file = array(
                'gif',
                'jpg',
                'jpeg',
                'png'
         );

         $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
         if (in_array($ext, $supported_file)) {
            //echo basename($image)."<br />"; // show only image name if you want to show full path then use this code // echo $image."<br />";''?>

         <div class="gallery">
  <a target="_blank" href="#">
   
    <?php echo '<img src="'.$image .'" alt="Random image" width="500px" height="400px"/>'; ?>
  </a>
  
</div>

<?php
           
            } else {
                continue;
            }
          }
       ?>
   </ul>
</div>
</div>
</div>
</div>
</body>