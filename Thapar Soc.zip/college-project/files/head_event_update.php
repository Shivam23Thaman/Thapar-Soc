<?php
@include 'connection.php';

if (isset($_POST['update'])) {
$id = $_POST['id'];
$image = $_FILES['image']['name'];
$name = $_POST['name'];
$des = $_POST['description'];
$event = $_POST['date'];
$notice = $_FILES['notice']['name'];

echo $image.'<br>';
echo $name.'<br>';
echo $des.'<br>';
echo $event.'<br>';
echo $notice.'<br>';




	
	$query = "UPDATE `images` SET image= '$image', name = '$name', description = '$des', datee = '$event', notes = '$notice' WHERE id = '$id' ";
	$target = "upload/".basename($image);
$tar = "upload/".basename($notice);


		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "Failed to upload image";
	}
	if (move_uploaded_file($_FILES['image']['tmp_name'], $tar)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "Failed to upload image";
	}
	}
	if(mysqli_query($conn, $query)){
		echo 'success';
		header("Location: dash.php");
	}
	else{
		mysqli_error($conn);
	}

	?>
