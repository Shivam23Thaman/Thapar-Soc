<?php
	include('conn.php');
	$fileinfo=PATHINFO($_FILES["image"]["name"]);
	$name = $_POST['name'];
	$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
	move_uploaded_file($_FILES["image"]["tmp_name"],"upload/" . $newFilename);
	$location="upload/" . $newFilename;
	
	
	echo $name;

	mysqli_query($con,"insert into image_tb (img_location,society_name) values ('$location','$name')") or  die(mysqli_error($con));;
	//header('location:index.php');
?>