<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['msg'])){ ?>
<div class="alert alert-warning"><?php echo $_SESSION['msg']; ?></div>
<?php unset($_SESSION['msg']);} ?>

<?php
if(isset($_SESSION['id'])){
   header('location:dash.php');
}
?>
<html lang="en">
<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="main-wrapper"  style="background-color: #f2f7f8;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-center">
                <li style="list-style-type:none;">   <a href="index.php">HOME</a></li>
                    <h3 style="padding-top: 30px;">Login/Sign up Form</h3>
                </div>
            </div>
            <div class="row" style="padding-top: 110px; padding-bottom: 110px;">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="card">
                        <div class="card-block">
                            <h4 class="card-title text-center">Log In</h4>
                            <form class="form-horizontal form-material" action="login_check.php" method="post">  
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12">Email</label>
                                            <div class="col-md-12">
                                                <input type="email" class="form-control form-control-line" name="email" id="email">
                                            </div>
                                        </div>
                                    </div>
                                </div>                    
                                <div class="form-group">
                                    <label class="col-md-12">Password</label>
                                    <div class="col-md-12">
                                        <input type="password" class="form-control form-control-line" name="password" required="required">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                    <div class="col-sm-12 col-md-12">
                                        <button class="btn btn-success" type="submit">Log IN</button>
                                    </div>
                                    
                                </div>
                                    <div class="col-sm-12">
                                        <a href="forget_password.php" class="text-primary">Forget Password?</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
              
    </div>
</div>
<?php @include 'footer.php'; ?>
</body>
</html>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Parent Login</h4>
      </div>
      <div class="modal-body">
        <form class="form-horizontal form-material" action="parent_login.php" method="post">  
                                <div class="row">
                                    <div class="col-md-12"> 
                                        <div class="form-group">
                                            <label class="col-md-12">Parent ID</label>
                                            <div class="col-md-12">
                                                <input type="text" class="form-control form-control-line" id=parent_id name="parent_id" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>                    
                                <div class="form-group">
                                    <label class="col-md-12">Password</label>
                                    <div class="col-md-12">
                                        <input type="password" class="form-control form-control-line" name="password" required="required">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12 col-md-12">
                                        <button class="btn btn-success" type="submit">Log IN</button>
                                    </div>
                                </div>
                            </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>