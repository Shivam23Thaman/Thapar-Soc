<?php
@include 'connection.php';
$email = $_POST['email'];
$password = $_POST['password'];

$query = mysqli_query($conn,"SELECT * FROM `users` WHERE `email` = '$email'");
$row = mysqli_fetch_assoc($query);

$dbpass = $row['password'];

if($password == $dbpass){
	$_SESSION['id'] = $row['id'] ;
	$_SESSION['msg'] = 'Login successful';
		header('location:dash.php');
}
else{
	$_SESSION['msg'] = 'Invalid Email or Passwordd';
	header('location:login.php');
}

?>