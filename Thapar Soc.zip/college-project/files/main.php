<?php
@include 'connection.php';

$act = $_GET['act'];

switch($act){

	case 'signup':

	$email = $_POST['email'];
	$name = $_POST['name'];
	$course = $_POST['course'];
	$semester = $_POST['semester'];
	$password = $_POST['password'];

	$query = mysqli_query($conn,"SELECT `id` FROM `users` wincache_refresh_if_changed() `email` = '$email'");
	$id = mysqli_num_rows($query);
	if($id){
		$_SESSION['msg'] = 'Email Already Exists';
		header('location:login.php');
	}else{
		$query = "INSERT INTO `users`(email,password,name,course,semester,role) VALUES('$email','$password','$name','$course','$semester','student')";
		if(mysqli_query($conn,$query)){
			$uid = mysqli_insert_id($conn);
			$_SESSION['id'] = $uid;
			$_SESSION['msg'] = 'Signup Successful';
			//$url = 'index.php';
		}	
	}
	break;

	case 'event':
$id = $_SESSION['id'];
	if (isset($_POST['upload'])) {
	    // Get image name$id = $_SESSION['id'];
		$image = $_FILES['image']['name'];
	    // Get text
		$image_text = mysqli_real_escape_string($conn, $_POST['name']);
		$des = mysqli_real_escape_string($conn, $_POST['description']);
		$so = mysqli_real_escape_string($conn, $_POST['society']);
		$da = mysqli_real_escape_string($conn, $_POST['datee']);
	    // image file directory
		$notice = $_FILES['note']['name'];
		$target = "upload/".basename($image);
		$tar = "upload/".basename($notice);


		mysqli_query($conn, "INSERT INTO images (image,name,description,society,datee,notes,user_id) VALUES ('$image', '$image_text','$des','$so','$da','$notice',$id)")or  die(mysqli_error($conn));
	    // execute query


		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "Failed to upload image";
		}

		if (move_uploaded_file($_FILES['note']['tmp_name'], $tar)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "Failed to upload image";
		}
	}

	break;
	case 'society':

	if (isset($_POST['upload'])) {
	    // Get image name
		$image = $_FILES['image']['name'];
	    // Get text
		$image_text = mysqli_real_escape_string($conn, $_POST['society_name']);
		$des = mysqli_real_escape_string($conn, $_POST['description']);
		$event = mysqli_real_escape_string($conn, $_POST['event']);
		$head_post = mysqli_real_escape_string($conn, $_POST['head']);
		$head = explode(",", $head_post)[1];
		$head_id = explode(",", $head_post)[0];


	    // image file directory
		$target = "uploads/".basename($image);

		mysqli_query($conn, "INSERT INTO society (image,society_name,description,event,	head, user_id) VALUES ('$image', '$image_text','$des','$event','$head', '$head_id')")or  die(mysqli_error($conn));
	    // execute query


		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "Failed to upload image";
		}
	}
	break;
	case 'cont':


	$name = $_POST['name'];
	$rol = $_POST['roll'];
	$phn = $_POST['phn'];
	$branch = $_POST['branch'];
	$course = $_POST['course'];
	$semester = $_POST['semester'];
	$email = $_POST['email'];
	$so = $_POST['society'];
	//$password = $_POST['password'];
//mysqli_query($conn,"INSERT INTO `quiz`(name,total_ques) VALUES('$name','$ques')");
	
	mysqli_query($conn,"INSERT INTO `cont`(name,roll_no,phn,branch,course,year,email,society_id) VALUES('$name','$rol','$phn','$branch','$course','$semester','$email','$so')")
	or die(mysqli_error($conn));
	break;
	case 'forget_password':

	$token = $_POST['token'];
	$email = $_POST['email'];
	mysqli_query($conn,"UPDATE `users` SET `token` = '$token' WHERE `email` = '$email' ");
	$url = 'forget_password1.php?email='.$email.'&token='.$token;
	break;

	case 'reset_password':

	$token = $_POST['token'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];

	if($password == $cpassword){
		mysqli_query($conn,"UPDATE `users` SET `password` = '$password', `token` = '' WHERE `token` = '$token' ");
		$url = 'login.php';
	}
	else{
		$_SESSION['msg'] = "Please Fill Matching passwords";
	}	
	break;

	case 'insert_assignment':

	$course = $_POST['course'];
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	$name = $_POST['name'];
	$submission_date = $_POST['submission_date'];
	$about = $_POST['about'];

	$token  = round(microtime(true));
	$extension="";
	$new_file_name="";
	if($_FILES['file']['name']!==""){
		$file_name = $_FILES['file']['name'];
		$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
		$file_tmp = $_FILES['file']['tmp_name'];
		$extension = explode('.', $file_name);
		$extension = strtolower(end($extension));
		$new_file_name = $filename."-".$token.".".$extension;

		if($extension=='doc' || $extension=='docx' || $extension=='pdf' || $extension=='jpeg' || $extension=='jpg' || $extension=='png')
		{
			move_uploaded_file($file_tmp,"uploads/".$new_file_name);
			$user_id = $_SESSION['id'];
			$query = "INSERT INTO `assignments`(`user_id`,`course`,`subject`,`semester`,`name`,`submission_date`,`about`,`file`) VALUES ('$user_id','$course','$subject','$semester','$name','$submission_date','$about','$new_file_name')";
			if(mysqli_query($conn, $query)){
				echo 'success';
			}
			else{
				echo 'Try again'.'<br>';
			}
		}
		else 
		{ 
			echo "Please upload a PDF or doc file.";
		}
	}

	break;

	case 'edit_assignment':

	$id = $_POST['id'];

	$course = $_POST['course'];
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	$name = $_POST['name'];
	$submission_date = $_POST['submission_date'];
	$about = $_POST['about'];
	
	$token  = round(microtime(true));
	$extension="";
	$new_file_name="";
	if($_FILES['file']['name']!==""){
		$file_name = $_FILES['file']['name'];
		$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
		$file_tmp = $_FILES['file']['tmp_name'];
		$extension = explode('.', $file_name);
		$extension = strtolower(end($extension));
		$new_file_name = $filename."-".$token.".".$extension;

		if($extension=='doc' || $extension=='docx' || $extension=='pdf' || $extension=='jpeg' || $extension=='jpg' || $extension=='png')
		{
			@unlink("uploads/".$_POST['file']);
			move_uploaded_file($file_tmp,"uploads/".$new_file_name);
		}
		else 
		{ 
			echo "Please upload a PDF or doc file.";
		}
	}
	else{
		$new_file_name = $_POST['file'];
	}

	$query = "UPDATE `assignments` SET `course` = '$course', `subject` = '$subject', `semester` = '$semester', `name` = '$name', `submission_date` = '$submission_date', `about` = '$about', `file` = '$new_file_name' WHERE `id` = '$id' ";

	if(mysqli_query($conn, $query)){
		echo 'success';
	}
	else{
		echo 'Try again';
	}
	break;

	case 'del_assignment':
	$id = $_GET['id'];
	mysqli_query($conn,"DELETE FROM `assignments` WHERE `id` = '$id'");
	$_SESSION['msg'] = 'Deleted Successfully';
	break;
case 'del_event':
	$id = $_GET['id'];
	mysqli_query($conn,"DELETE FROM `images` WHERE `id` = '$id'");
	$_SESSION['msg'] = 'Deleted Successfully';
	break;
	case 'del_society':
	$id = $_GET['id'];
	mysqli_query($conn,"DELETE FROM `society` WHERE `id` = '$id'");
	$_SESSION['msg'] = 'Deleted Successfully';
	break;
	case 'insert_notes':

	$course = $_POST['course'];
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	$chapter_name = $_POST['chapter_name'];
	$about = $_POST['about'];
	$token  = round(microtime(true));
	$extension="";
	$new_file_name="";
	if($_FILES['file']['name']!==""){
		$file_name = $_FILES['file']['name'];
		$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
		$file_tmp = $_FILES['file']['tmp_name'];
		$extension = explode('.', $file_name);
		$extension = strtolower(end($extension));
		$new_file_name = $filename."-".$token.".".$extension;

		if($extension=='doc' || $extension=='docx' || $extension=='pdf' || $extension=='jpeg' || $extension=='jpg' || $extension=='png')
		{
			move_uploaded_file($file_tmp,"uploads/".$new_file_name);
			$user_id = $_SESSION['id'];
			$query = "INSERT INTO `notes`(`user_id`,`course`,`subject`,`semester`,`chapter_name`,`about`,`file`) VALUES ('$user_id','$course','$subject','$semester','$chapter_name','$about','$new_file_name')";

			if(mysqli_query($conn, $query)){
				$_SESSION['msg'] = 'Saved Successfully';
			}
			else{
				$_SESSION['msg'] = 'Try Again';
			}
		}
		else 
		{ 
			$_SESSION['msg'] = 'Please upload a PDF or doc file';
		}
	}
	
	break;


	case 'edit_notes':

	$id = $_POST['id'];

	$course = $_POST['course'];
	$subject = $_POST['subject'];
	$semester = $_POST['semester'];
	$chapter_name = $_POST['chapter_name'];;
	$about = $_POST['about'];
	
	$token  = round(microtime(true));
	$extension="";
	$new_file_name="";
	if($_FILES['file']['name']!==""){
		$file_name = $_FILES['file']['name'];
		$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
		$file_tmp = $_FILES['file']['tmp_name'];
		$extension = explode('.', $file_name);
		$extension = strtolower(end($extension));
		$new_file_name = $filename."-".$token.".".$extension;

		if($extension=='doc' || $extension=='docx' || $extension=='pdf' || $extension=='jpeg' || $extension=='jpg' || $extension=='jpg')
		{
			@unlink("uploads/".$_POST['file']);
			move_uploaded_file($file_tmp,"uploads/".$new_file_name);
		}
		else 
		{ 
			$_SESSION['msg'] = 'Please upload a PDF or doc file';
		}
	}
	else{
		$new_file_name = $_POST['file'];
	}

	$query = "UPDATE `notes` SET `course` = '$course', `subject` = '$subject',`semester` = '$semester', `chapter_name` = '$chapter_name', `about` = '$about', `file` = '$new_file_name' WHERE `id` = '$id' ";

	if(mysqli_query($conn, $query)){
		$_SESSION['msg'] = 'Updated Successfully';
	}
	else{
		$_SESSION['msg'] = 'Try Again';
	}
	break;

	case 'del_notes':
	$id = $_GET['id'];
	mysqli_query($conn,"DELETE FROM `notes` WHERE `id` = '$id'");
	$_SESSION['msg'] = 'Deleted Successfully';
	break;

	case 'change_semester':
	$sid = $_POST['sid'];
	$semester = $_POST['semester'];
	mysqli_query($conn,"UPDATE `users` SET `semester` = '$semester' WHERE `id` = '$sid' ");
	break;

	case 'mark_present':
	$teacher_id = $_SESSION['id'];
	$student_id = $_GET['id'];
	$course = $_GET['course'];
	$semester = $_GET['semester'];

	mysqli_query($conn, "INSERT INTO `attendance`(`teacher_id`,`student_id`,`date`,`status`,`course`,`semester`) VALUES('$teacher_id','$student_id',date(),'1','$course','$semester')");
	break;

	case 'save_atnd':
	$course = $_GET['course'];
	$semester = $_GET['sem'];
	$tid = $_SESSION['id'];
	$date = date("Y-m-d");
	// echo $course;
	// echo $semester;
	// echo $tid;
	// echo $date;

	$query = mysqli_query($conn,"SELECT `status` From `attendance` WHERE `teacher_id` = '$tid' AND `course` = '$course' AND `semester` = '$semester' AND `date` = '$date' AND `status` = '1' ");
	$present = mysqli_num_rows($query);

	$query1 = mysqli_query($conn,"SELECT `status` From `attendance` WHERE `teacher_id` = '$tid' AND `course` = '$course' AND `semester` = '$semester' AND `date` = '$date' AND `status` = '0' ");
	$absent = mysqli_num_rows($query1);

// echo "<br>".$present;
// echo "<br>".$absent;

	// mysqli_query($conn,"INSERT INTO `attendance_record` (`teacher_id`,`course`,`semester`,`date`,`present`,`absent`) VALUES('$tid','$course','$semester','$date','$present','$absent')");

	mysqli_query($conn, "INSERT INTO `attendance_record`(`teacher_id`,`course`,`semester`,`date`,`present`,`absent`) VALUES('$tid','$course','$semester','$date','$present','$absent')") or die(mysqli_error());

	break;

	case 'add_marks':
	$teacher_id = $_SESSION['id'];
	$student_id = $_POST['student'];
	$course = $_POST['course'];
	$semester = $_POST['semester'];
	$subject = $_POST['subject'];
	$total = $_POST['total'];
	$obtained = $_POST['obtained'];

	mysqli_query($conn, "INSERT INTO `marks`(`teacher_id`,`student_id`,`course`,`semester`,`subject`,`total`,`obtained`) VALUES('$teacher_id','$student_id','$course','$semester','$subject','$total','$obtained')") or die(mysqli_error());

	break;

	case 'add_quiz':
	$name = $_POST['name'];
	$ques = $_POST['total_ques'];
	mysqli_query($conn,"INSERT INTO `quiz`(name,total_ques) VALUES('$name','$ques')");
	break;

	case 'add_ques':
	$qid = $_GET['qid'];
	$ques = $_POST['ques'];
	$ans = $_POST['ans'];
	mysqli_query($conn,"INSERT INTO `questions`(quiz_id,question,answer) VALUES('$qid','$ques','$ans')");
	break;

	case 'add_options':
	$ques_id = $_GET['ques_id'];
	$option1 = $_POST['option1'];
	$option2 = $_POST['option2'];
	$option3 = $_POST['option3'];
	$option4 = $_POST['option4'];
	$options = [$option1,$option2,$option3,$option4];
	for($i = 0; $i<=3; $i++){

		$sql = "INSERT INTO `options`(question_id,options) VALUES('$ques_id','$options[$i]')";

		if (mysqli_query($conn, $sql)) {
			echo "New record created successfully";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
	break;

	case 'check_quiz':

	$id = $_GET['id'];
	$student_id = $_SESSION['id'];

	$query = mysqli_query($conn,"SELECT * FROM `questions` WHERE `quiz_id` = '$id'");
		//$total = 0;
	$right = 0;
	$wrong = 0;
	$tq = mysqli_num_rows($query);

	while($row = mysqli_fetch_assoc($query)){
		$qid = $row['id'];

		$answer = $row['answer'];

		$query1 = mysqli_query($conn,"SELECT * FROM `options` WHERE `question_id` = '$qid'");
		while($row1 = mysqli_fetch_assoc($query1)){
			$opid = $row1['id'];

			if(isset($_POST['question'][$qid][$opid])){
				$myAns = $_POST['question'][$qid][$opid];

				if($myAns == $answer){
					$right++;
				}else{
					$wrong++;
				}
			}
		}
	}
	// echo $tq.'<br>';
	// echo $right.'<br>';
	// echo $wrong.'<br>';

	mysqli_query($conn,"INSERT INTO `quiz_result`(`student_id`,`quiz_id`,`total_ques`,`right_ans`,`wrong_ans`) VALUES('$student_id','$id','$tq','$right','$wrong')");
	$url = 'all_quiz.php';

	break;

	case 'add_teacher':
	$email = $_POST['email'];
	$name = $_POST['name'];
	$password = $_POST['password'];
	
	$contact = $_POST['contact'];

	$query = mysqli_query($conn,"SELECT `id` FROM `users` WHERE `email` = '$email'");

	$id = mysqli_num_rows($query);
	if($id){
		$_SESSION['msg'] = 'Email Already Exists';
	}else{
		$query = "INSERT INTO `users`(email,password,name,role,contact) VALUES('$email','$password','$name','teacher','$contact')";

		mysqli_query($conn,$query);
		$_SESSION['msg'] = 'Head Added';
	}
	break;
	
	case 'add_member':
	$u_id = $_SESSION['id'];

	$email = $_POST['email'];
	$name = $_POST['name'];
	$password = $_POST['password'];
	
	$contact = $_POST['roll'];

	$query = mysqli_query($conn,"SELECT `id` FROM `users` WHERE `email` = '$email'");

	$id = mysqli_num_rows($query);
	if($id){
		$_SESSION['msg'] = 'Email Already Exists';
	}else{
		$query = "INSERT INTO `users`(email,password,name,role,contact) VALUES('$email','$password','$name','member','$contact')";
		mysqli_query($conn,$query);

		$q = mysqli_query($conn,"SELECT * FROM 'users' WHERE 'email'='$email'");
		$res=mysqli_query($conn,$q);

		$row = mysqli_fetch_assoc($q);
		$qid = $row['id'];

		$qq = mysqli_query($conn,"SELECT * FROM 'society' WHERE 'user_id'='$u_id'");
		$ress=mysqli_query($conn,$qq);
		$row = mysqli_fetch_assoc($qq);
		$sid = $row['id'];


		mysqli_query($conn,$qu);

		$query = "INSERT INTO `society_member`(user_id,society_id) VALUES('$qid','$sid')";
		mysqli_query($conn,$query);

		$_SESSION['msg'] = 'Member Added';
	}
	

	break;

	

	case 'society_up':
	
	//$name = $_POST['id'];
	
	echo "string";
	//echo $name;

	break;
	case 'del_user':

	$id = $_GET['id'];
	mysqli_query($conn, "DELETE FROM `users` WHERE `id` = '$id' ");

	// $_SESSION['msg'] = "User Deleted";
	break;

	case 'show_students':
	
	break;

	case 'member_update':

	$id = $_GET['id'];

	break;

	case 'logout':
	session_destroy();
	session_start();
	$_SESSION['msg'] = 'Logged Out Successfully';
	$url = 'login.php';
	break;


	case 'insert_gallery':

	
	$token  = round(microtime(true));
	$extension="";
	$new_file_name="";
	if($_FILES['file']['name']!==""){
		$file_name = $_FILES['file']['name'];
		$filename = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
		$file_tmp = $_FILES['file']['tmp_name'];
		$extension = explode('.', $file_name);
		$extension = strtolower(end($extension));
		$new_file_name = $filename."-".$token.".".$extension;

		if($extension=='doc' || $extension=='docx' || $extension=='pdf' || $extension=='jpeg' || $extension=='jpg' || $extension=='png')
		{
			move_uploaded_file($file_tmp,"gallery/".$new_file_name);
			$user_id = $_SESSION['id'];
			$query = "INSERT INTO `notes`(`user_id`,`file`) VALUES ('$user_id','$new_file_name')";

			if(mysqli_query($conn, $query)){
				$_SESSION['msg'] = 'Saved Successfully';
			}
			else{
				$_SESSION['msg'] = 'Try Again';
			}
		}
		else 
		{ 
			$_SESSION['msg'] = 'Please upload a PDF or doc file';
		}
	}
	break;
}
if($url){
	header("location:". $url);
}else{
	header('Location: ' . $_SERVER['HTTP_REFERER']);	
}
?>