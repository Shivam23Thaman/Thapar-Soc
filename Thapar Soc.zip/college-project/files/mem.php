<?php

include 'connection.php';
$u_id = $_SESSION['id'];

	$email = $_POST['email'];
	$name = $_POST['name'];
	$password = $_POST['password'];
	
	$contact = $_POST['roll'];

	$query = mysqli_query($conn,"SELECT `id` FROM `users` WHERE `email` = '$email'");

	$id = mysqli_num_rows($query);
	// if($id){
		// $_SESSION['msg'] = 'Email Already Exists';
	// }else{
	$query = "INSERT INTO `users`(email,password,name,role,contact) VALUES('$email','$password','$name','member','$contact')";
	mysqli_query($conn,$query);
	
	$q = "SELECT * FROM users WHERE email='$email'";
	$res=mysqli_query($conn,$q);
	
	$row = mysqli_fetch_assoc($res);
	$qid = $row['id'];

	 echo "hello";
	 echo $qid;
	
	$sid = "SELECT * FROM society WHERE user_id ='$u_id'";
	$ress=mysqli_query($conn,$sid);
	$row = mysqli_fetch_assoc($ress);
	$ssid = $row['id'];
	echo "<br>";
	echo $ssid.'<br>';

	$queryy = "INSERT INTO `society_members`(user_id,society_id) VALUES('$qid','$ssid')";
	mysqli_query($conn,$queryy);

	// }
header('location:dash.php');
	?>