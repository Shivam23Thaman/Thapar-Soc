<nav class="navbar navbar-expand-sm bg-light">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="http://localhost/college-project/files/forum-js/forum.php">Forum</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="gallery_image.php">Gallery</a>

    </li>
     <li class="nav-item">
      <a class="nav-link" href="user_event.php">Events</a>  
    </li>
     <li class="nav-item">
      <a class="nav-link" href="user-society.php">Societies</a>
      
    </li>
     <li class="nav-item">
      <a class="nav-link" href="login.php">Login</a>
      
    </li>
	 </ul>
</nav>