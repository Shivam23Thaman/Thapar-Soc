<?php
@include 'connection.php';
$pid = $_POST['parent_id'];
$password = $_POST['password'];

$query = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$pid'");
$row = mysqli_fetch_assoc($query);

$dbpass = $row['password'];

if($password == $dbpass){
	$_SESSION['id'] = $row['id'];
	$_SESSION['parent'] = $row['id'];
	$_SESSION['msg'] = 'Login successful';
		header('location:index.php');
}
else{
	$_SESSION['msg'] = 'Invalid Email or Passwordd';
	header('location:login.php');
}

?>