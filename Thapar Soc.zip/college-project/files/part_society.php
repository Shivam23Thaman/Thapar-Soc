<!DOCTYPE html>
        <?php @include 'config.php'; ?>
        <html lang="en">

        <head>
        <?php @include 'meta.php'; ?>
        </head>

        <body class="fix-header fix-sidebar card-no-border">
        <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
        <?php @include 'header.php'; ?>
        <?php @include 'sidebar.php'; ?>
        <div class="page-wrapper">
        <div class="container-fluid">
        <div class="row page-titles">
            <div class="col-md-6 col-8 align-self-center">
                <h3 class="text-themecolor m-b-0 m-t-0">Society</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active">All Society</li>
                </ol>
            </div>
            <div class="col-md-6 col-4 align-self-center">
            </div>
        </div>
        <!-- Row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title">All Society</h4>
                        <div class="table-responsive m-t-40">
                            <table class="table stylish-table">
                                <thead>
                                    <tr>
                                        <th colspan="2">Society Name</th>
                                        <th>Description</th>
                                        <th>Event</th>
                                        <th>Image</th>
                                        <th>Head Name</th>
                                        <th>Delete</th>
                                        <th>View</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //$userid=$_SESSION['name'];
                                    $id = $_SESSION['id'];
                                   
                                   //$result = mysqli_query($conn,"SELECT  *FROM society INNER JOIN  users ON society.user_id = users.id");
                                   //while($row = mysqli_fetch_assoc($result)){
                                    $result = mysqli_query($conn,"SELECT * FROM society WHERE user_id = $id");
                                   while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    <tr>
                                        <td style="width:50px;"><span class="round"><?php echo $row['id']; ?></span></td>
                                        <td>
                                            <h6><?php echo $row['society_name']; ?></h6></td>
                                        <td><?=$row['description'];?></td>
                                        <td><?=$row['event'];?></td>
                                        <td><?=$row['image'];?></td>
                                        <td><?=$row['head'];?></td>
                                        <td><a href="main.php?act=del_society&id=<?=$row['id'];?>" class="btn btn-warning">Delete</a></td>
                                        <td><a href="view_society.php?act=view_soc&id=<?=$row['id'];?>" class="btn btn-warning">View</a></td>
                                        <td><a href="society_update.php?act=view_soc&id=<?=$row['id'];?>" class="btn btn-warning">Edit</a></td>

                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
        </div>
        <footer class="footer text-center">
        Thapar Soc
        </footer>
        </div>
        </div>
        <?php @include 'footer.php'; ?>
        </body>
        </html>