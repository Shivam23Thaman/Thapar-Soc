<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <?php
                $id = $_SESSION['id'];
                $query = mysqli_query($conn,"SELECT `role`,`id`,`semester` from `users` WHERE `id` = '$id'");
                $row = mysqli_fetch_assoc($query);
            
                if(($row['role'] == 'student') && (!isset($_SESSION['parent']))){ ?>
                <li>
                    <a href="index.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                </li>
                <li>
                    <a href="student_assignments.php" class="waves-effect"><i class="fa fa-file m-r-10" aria-hidden="true"></i>All Assignments</a>
                </li>
                <li>
                    <a href="student_notes.php" class="waves-effect"><i class="fa fa-envelope-open m-r-10" aria-hidden="true"></i>All Notes</a>
                </li>
                <li>
                    <a href="student_attendance.php" class="waves-effect"><i class="fa fa-eject m-r-10" aria-hidden="true"></i>Attendance</a>
                </li>
                <li>
                    <a href="student_marks.php" class="waves-effect"><i class="fa fa-exchange m-r-10" aria-hidden="true"></i>View Marks</a>
                </li>
                <li>
                    <a href="all_quiz.php" class="waves-effect"><i class="fa fa-expeditedssl m-r-10" aria-hidden="true"></i>Play Quiz</a>
                </li>
                <li>
                    <a href="#changeSem" data-id="<?=$row['id'];?>" data-semester="<?=$row['semester'];?>" data-toggle="modal" data-target="#changeSem" class="waves-effect chgSem"><i class="fa fa-book m-r-10" aria-hidden="true"></i>Change Semester</a>
                </li> 

                <?php }
                else if($row['role'] == 'teacher') {  ?>
                <li>
                    <a href="index.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                </li>
               <li>
                    <a href="part_society.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>All Society</a>
                </li>
                               
                <li>
                    <a href="cont.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>Enroll</a>
                </li>  
                <li>
                    <a href="add_member.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>Add Member</a>
                </li> 
                <li>
                    <a href="part_event.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>All event</a>
                </li>  
                
                <li><a href="event.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>Add event</a></li>
              
                

                <?php } else if($row['role'] == 'admin'){ ?>
                <li>
                    <a href="index.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                </li>
               <li>
                    <a href="add_teacher.php" class="waves-effect"><i class="fa fa-plus m-r-10" aria-hidden="true"></i>Add Head</a>
                </li>

                <li>
                    <a href="add_society.php" class="waves-effect"><i class="fa fa-plus m-r-10" aria-hidden="true"></i>Add  Society </a>
                </li>
                
                <li>
                    <a href="all_teachers.php" class="waves-effect"><i class="fa fa-list m-r-10" aria-hidden="true"></i>All Head</a>
                </li>
                <li>
                    <a href="all_society.php" class="waves-effect"><i class="fa fa-list m-r-10" aria-hidden="true"></i>All Societies</a>
                </li>
                <li>
                    <a href="head_ee.php" class="waves-effect"><i class="fa fa-plus m-r-10" aria-hidden="true"></i>Add  event </a>
                </li>
                
                 <li>
                    <a href="all_event.php" class="waves-effect"><i class="fa fa-plus m-r-10" aria-hidden="true"></i>all event </a>
                </li>
                
                     <?php } else if($row['role'] == 'member'){ ?>
                <li>
                    <a href="index.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                <li>
                    <a href="mem_society.php" class="waves-effect"><i class="fa fa-list m-r-10" aria-hidden="true"></i>Societies</a>
                </li>
                <li>
                    <a href="member_add_event.php" class="waves-effect"><i class="fa fa-list m-r-10" aria-hidden="true"></i>Add Event</a>
                </li>
                 <li>
                    <a href="part_event.php" class="waves-effect"><i class="fa fa-list m-r-10" aria-hidden="true"></i>All Event</a>
                </li>

                <?php } elseif(isset($_SESSION['parent'])){?>
                      <li>
                    <a href="student_attendance.php" class="waves-effect"><i class="fa fa-eject m-r-10" aria-hidden="true"></i>Attendance</a>
                </li>
                <li>
                    <a href="student_marks.php" class="waves-effect"><i class="fa fa-exchange m-r-10" aria-hidden="true"></i>View Marks</a>
                </li>
                <?php } ?>
                <li>
                    <a href="contact.php" class="waves-effect"><i class="fa fa-address-card m-r-10" aria-hidden="true"></i>Contact</a>
                </li> 
                <li>
                    <a href="main.php?act=logout" class="waves-effect"><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>

<div id="changeSem" class="modal fade chgSem" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Change Semester</h4>
    </div>
    <form method="post" action="main.php?act=change_semester">
    <div class="modal-body">

     <input type="hidden" name="sid" class="student_id">
     <input type="text" class="semester form-control form-control-line" readonly="">

     <div class="form-group">
        <label class="col-md-12">Semester</label>
        <div class="col-md-12">
         <select class="form-control form-control-line" name="semester"  required="required">
            <option value="">Select</option>
            <option>1st</option>
            <option>2nd</option>
            <option>3rd</option>
            <option>4th</option>
            <option>5th</option>
            <option>6th</option>
        </select>
    </div>
</div>
</div>

<div class="modal-footer">
    <input type="submit" value="Submit" class="btn btn-primary">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</form>
</div>

</div>
</div>