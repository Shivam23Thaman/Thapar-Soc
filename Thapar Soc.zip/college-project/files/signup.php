<!DOCTYPE html>
<?php
session_start();
if(isset($_SESSION['msg'])){ ?>
<div class="alert alert-warning"><?php echo $_SESSION['msg']; ?></div>
<?php } ?>
<html lang="en">
<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="main-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-md-offset-3">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Log In</h4>
                                <form class="form-horizontal form-material" action="login_check.php" method="post">                      
                                    <div class="form-group">
                                        <label class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="email" class="form-control form-control-line" name="email" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Password</label>
                                        <div class="col-md-12">
                                            <input type="password" class="form-control form-control-line" name="password" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button class="btn btn-success" type="submit">Log IN</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </body>
    </html>