<?php
$con = mysqli_connect("localhost","root","root","college");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>

<?php
  include('conn.php');
  $fileinfo=PATHINFO($_FILES["image"]["name"]);
  $name = $_POST['society_name'];
  $des = $_POST['description'];
  $event = $_POST['event'];
  $head = $_POST['head'];
  $newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
  move_uploaded_file($_FILES["image"]["tmp_name"],"society/" . $newFilename);
  $location="society/" . $newFilename;
  
  


  mysqli_query($con,"insert into society (image,society_name,description,event,head) values ('$location','$name','$des','$event','$head')") or  die(mysqli_error($con));;
  //header('location:index.php');
?>  