<!DOCTYPE html>
<?php @include 'config.php'; ?>
<html lang="en">

<head>
    <?php @include 'meta.php'; ?>
</head>

<body class="fix-header fix-sidebar card-no-border">
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
            <?php @include 'header.php'; ?>
            <?php @include 'sidebar.php'; ?>
            <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row page-titles">
                        <div class="col-md-6 col-8 align-self-center">
                            <h3 class="text-themecolor m-b-0 m-t-0">Society</h3>
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active">All Societies</li>
                            </ol>
                        </div>
                        <div class="col-md-6 col-4 align-self-center">
                        </div>
                    </div>
                    <!-- Row -->
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-block">
                                    <h4 class="card-title">Societies</h4>

                                    <?php
                                    $id = $_GET['id'];
                                    $result = mysqli_query($conn,"SELECT * FROM `society` WHERE `id` = $id ");
                                    while($row = mysqli_fetch_assoc($result)){
                                        ?>
                                        <form class="form-horizontal form-material" action="update_back.php" method="post" enctype="multipart/form-data">  
                                         <div class="form-group">
                                           <input type="hidden" class="form-control form-control-line" name="id" value="<?php echo $row['id']; ?>">
                                           <label class="col-md-12">image</label>
                                           <div class="col-md-12">
                                            <input type="file" class="form-control form-control-line" name="image">
                                            
                                        </div>
                                        <label class="col-md-12">Name</label>
                                        <div class="col-md-12">
                                           <input type="text" class="form-control form-control-line" name="sname" value="<?php echo $row['society_name']; ?>">

                                       </div>
                                       <label class="col-md-12">Description</label>
                                       <div class="col-md-12">
                                           <input type="text" class="form-control form-control-line" name="description" value="<?php echo $row['description']; ?>">

                                       </div>
                                       <label class="col-md-12">event</label>
                                       <div class="col-md-12">
                                           <input type="text" class="form-control form-control-line" name="event" value="<?php echo $row['event']; ?>">

                                       </div>
                                       <label class="col-md-12">head</label>
                                       <div class="col-md-12">
                                           <input type="text" class="form-control form-control-line" name="head" value="<?php echo $row['head']; ?>">

                                       </div>


                                   </div>   
                                   <button class="btn btn-success" type="submit" name="update">Update</button>
                                   <?php } ?>


                               </div>
                           </div>
                       </div>
                   </div>
                   <!-- Row -->
               </div>
               <footer class="footer text-center">
                Thapar Soc
            </footer>
        </div>
    </div>
    <?php @include 'footer.php'; ?>
</body>
</html>