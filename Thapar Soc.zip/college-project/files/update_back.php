<?php
@include 'connection.php';

if (isset($_POST['update'])) {
	$id = $_POST['id'];
	$image = $_FILES['image']['name'];
	$name = $_POST['sname'];
	$des = $_POST['description'];
	$event = $_POST['event'];
	$head = $_POST['head'];

echo $image;
	
	$query = "UPDATE society SET image= '$image',society_name = '$name', description = '$des', event = '$event', head = '$head' WHERE id = '$id' ";
$target = "uploads/".basename($image);

	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
			//$msg = "Image uploaded successfully";
	}else{
		$msg = "Failed to upload image";
	}
	
	
}if(mysqli_query($conn, $query)){
		echo 'success';
		header("Location: dash.php");
	}
	else{
		mysqli_error($conn);
	}

?>
