<!DOCTYPE html>
        <?php @include 'connection.php'; ?>
        <html lang="en">

       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <style>
  	 .carousel-inner img {
      width: 100%;
      height: 100%;
  }
    .card-title {
    margin-bottom: .75rem;
    background: #e9ecef;
    padding: 20px;
}
  </style>
  
	<title></title>
</head>
<?php include 'nav.php';
  ?>
        <body class="fix-header fix-sidebar card-no-border">
        <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
        <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
        </div>
        <div id="main-wrapper">
        
        
        <div class="page-wrapper">
        <div class="container-fluid">
        <div class="row page-titles">
            <hr>
            <div class="col-md-6 col-4 align-self-center">
            </div>
        </div>
        <!-- Row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-block">
                        <h4 class="card-title">All Events</h4>
                        <div class="table-responsive m-t-40">
                            <table class="table stylish-table">
                                <thead>
                                    <tr>
                                        <th >Event Name</th>
                                        <th>Description</th>
                                        <th>scoiety</th>
                                        <th>date</th>
                                           <th>View</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //$id = $_SESSION['id'];
                                   //$result = mysqli_query($conn,"SELECT so_id FROM users INNER JOIN society")
                                   $result = mysqli_query($conn,"SELECT  *FROM images");
                                   while($row = mysqli_fetch_assoc($result)){
                                    ?>
                                    <tr>
                                                                                <td>
                                            <h6><?php echo $row['name']; ?></h6></td>
                                        <td><?=$row['description'];?></td>
                                        <td><?=$row['society'];?></td>
                                        <td><?=$row['datee'];?></td>
                                        
                                        
                                        <td><a href="view_event.php?act=view_soc&id=<?=$row['id'];?>" class="btn btn-warning">View</a></td>


                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
        </div>
        <footer class="footer text-center">
        Thapar Soc
        </footer>
        </div>
        </div>
        <?php @include 'footer.php'; ?>
        </body>
        </html>