
<?php
include 'connection.php';

?>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <style>
    .card-block {
    background-color: #f8f9fa!important;
    box-shadow: 0px 5px 5px #000;
}
.s
{
width: 100%;
height: 600px;
}
  </style>


</head>
<body>
    <?php include 'nav.php';
  ?>
<br>
<div class="container">
    <div class="card">
                    <div class="card-block">
                        <center><h4 class="card-title">Society</h4></center>
                        
                            
            <?php
                    $id = $_GET['id'];
                    $result = mysqli_query($conn,"SELECT * FROM `society` WHERE `id` = $id ");
                     while($row = mysqli_fetch_assoc($result)){?>
                     <div class="alert alert-success">

                      <h3> Society Image </h3>  
                       
                     <?php echo "<img  class='s' src='uploads/".$row['image']."' >";?>
                   </div>
                     <div class="alert alert-success">

                      <h3> Society Name </h3> 
                      <?php echo $row['society_name']; ?>
                      </div>
                    <div class="alert alert-success">
                     <h3>Description</h3>
                     <label class="col-md-12"><?=$row['description']; ?></label>
                   </div>
                    <div class="alert alert-success">
                     <h3>Event</h3>
                     <label class="col-md-12"><?=$row['event']; ?></label>
                   </div>
                    <div class="alert alert-success">
                     <h3>Head Name</h3>

                     <label class="col-md-12"><?=$row['head']; ?></label>
                   </div>

              
            <?php } ?>
  <a class="btn btn-warning" href="enrol.php?id=<?=$_GET['id'];?>"> Enroll </a>
            
       
    </div>

</div><br>
<button src="enrol.php"
</div>
<?php
include 'footer.php'; ?>
</body>
